﻿namespace FlyleafLib.MediaFramework.MediaFrame;

public class AudioFrame : FrameBase
{
    public IntPtr   dataPtr;
    public int      dataLen;
    public double   speed = 1;
}
